// ===============================================
//  content.js
//  Injected into copilot.microsoft.com
//  Watches for new Copilot messages and sends them
//  to background.js → backend.py
// ===============================================

// Helper: send message to background.js
function sendToBackend(text) {
    chrome.runtime.sendMessage({
        type: "copilot_to_backend",
        text: text
    });
}

// ===============================================
//  Observe Copilot's chat output
// ===============================================

// Select the chat container
function getChatContainer() {
    return document.querySelector('[data-testid="conversation-turns"]');
}

// Extract text from a Copilot message bubble
function extractMessageText(node) {
    if (!node) return "";

    // Copilot messages often contain <p>, <span>, <div>
    const text = node.innerText || node.textContent || "";
    return text.trim();
}

// Watch for new messages
function startObserver() {
    const container = getChatContainer();
    if (!container) {
        console.log("Copilot container not found, retrying...");
        setTimeout(startObserver, 1000);
        return;
    }

    console.log("Copilot container found. Starting observer.");

    const observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (!(node instanceof HTMLElement)) continue;

                // Copilot messages usually have role="article"
                if (node.getAttribute("role") === "article") {
                    const text = extractMessageText(node);
                    if (text.length > 0) {
                        console.log("Copilot message detected:", text);
                        sendToBackend(text);
                    }
                }
            }
        }
    });

    observer.observe(container, {
        childList: true,
        subtree: true
    });
}

// Start observing once the page loads
window.addEventListener("load", () => {
    setTimeout(startObserver, 1500);
});
