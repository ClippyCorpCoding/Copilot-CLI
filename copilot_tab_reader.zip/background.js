// ===============================
//  CONFIG
// ===============================
const BACKEND_URL = "http://127.0.0.1:5005";


// ===============================
//  1. EXTENSION → BACKEND
//  Receive messages from content.js (Copilot output)
//  and forward them to the backend.
// ===============================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "copilot_to_backend") {
        fetch(`${BACKEND_URL}/copilot`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bash: msg.text })
        })
        .then(() => sendResponse({ status: "ok" }))
        .catch(err => sendResponse({ status: "error", error: err.toString() }));

        return true; // keep channel open
    }
});


// ===============================
//  2. BACKEND → EXTENSION → COPILOT
//  Poll backend for messages that should be sent TO Copilot.
// ===============================
async function pollBackend() {
    try {
        const res = await fetch(`${BACKEND_URL}/send_to_copilot`, {
            method: "GET",
            headers: { "Cache-Control": "no-cache" }
        });

        if (!res.ok) return;

        const data = await res.json();
        if (!data.text) return;

        // Inject into Copilot tab
        sendToCopilotChat(data.text);

    } catch (err) {
        console.log("Polling error:", err);
    }
}

// Poll every 1 second
setInterval(pollBackend, 1000);


// ===============================
//  3. Inject message into Copilot
//     (with Enter key delay fix)
// ===============================
function sendToCopilotChat(text) {
    chrome.tabs.query({ url: "*://copilot.microsoft.com/*" }, tabs => {
        if (tabs.length === 0) return;

        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: (message) => {
                const textarea = document.querySelector("textarea");
                if (!textarea) {
                    console.log("Textarea not found.");
                    return;
                }

                // Type the message
                textarea.value = message;
                textarea.dispatchEvent(new Event("input", { bubbles: true }));

                // Delay to let React update
                setTimeout(() => {
                    // Find the send button by aria-label
                    const sendButton =
                        document.querySelector('button[aria-label*="send" i]') ||
                        document.querySelector('button[aria-label*="submit" i]') ||
                        document.querySelector('button[aria-label*="message" i]');

                    if (!sendButton) {
                        console.log("Send button not found.");
                        return;
                    }

                    sendButton.click();
                }, 50);
            },
            args: [text]
        });
    });
}
